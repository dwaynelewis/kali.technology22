A Pen created at CodePen.io. You can find this one at https://codepen.io/digitalhour/pen/WvGJVV.

 Wave dots. something I got from three.js 